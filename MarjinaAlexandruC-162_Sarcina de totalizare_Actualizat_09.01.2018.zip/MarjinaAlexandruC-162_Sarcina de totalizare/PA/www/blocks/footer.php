<div id="f">
  <div class="container">
    <div class="row centered">

      <a target="_blank" href="https://www.facebook.com/alexandru.marjina"><i class="fa fa-facebook"></i></a>
      <a href="#"><i class="fa fa-instagram"></i></a>
      <a href="#"><i class="fa fa-vk"></i></a>
    </div>
    <center>
    <a href="admin/index.php"><p>Toate drepturile aparate &copy; <?=date('Y')?> Marjina Alexandru</p></a>
  </center>
  </div>
</div>
</body>
</html>
