<div id="f">
  <div class="container">
    <div class="row centered">

      <a target="_blank" href="https://www.facebook.com/alexandru.marjina"><i class="fa fa-facebook"></i></a>
      <a href="#"><i class="fa fa-instagram"></i></a>
      <a href="#"><i class="fa fa-vk" aria-hidden="true"></i></a>
    </div>
    <center>
    <p>Toate drepturile aparate &copy; <?=date('Y')?> Marjina Alexandru</p>
  </center>
  </div>
</div>
</body>
</html>
