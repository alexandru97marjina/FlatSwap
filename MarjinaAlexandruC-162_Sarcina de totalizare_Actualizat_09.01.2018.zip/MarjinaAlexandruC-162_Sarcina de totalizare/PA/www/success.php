<?php
    session_start();
    echo "ati trimis reusit mesajul pe emailul ".$_SESSION["to"];
 ?>
